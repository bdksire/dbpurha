import React from 'react'

export const AnimatedCircularIcon = () => {
  return (
    <div>AnimatedCircularIcon</div>
  )
}
