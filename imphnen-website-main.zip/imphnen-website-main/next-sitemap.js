module.exports = {
    siteUrl: 'https://nextjs-landing-starter.vercel.app', // yourdomain
    generateRobotsTxt: true,
    sitemapSize: 7000,
};
